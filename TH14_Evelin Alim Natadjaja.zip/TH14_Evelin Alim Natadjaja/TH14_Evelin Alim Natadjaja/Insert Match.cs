﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;

namespace TH14___Evelin_Alim_Natadjaja
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }
        //Nama : Evelin Alim Natadjaja
        //NIM : 0706022310021

        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string sqlQuery;

        DataTable dtMatchDate;
        DataTable dtTeamHome;
        DataTable dtTeamAway;
        DataTable dtPlayer;
        DataTable dtselectedTeam;
        DataTable dtdmatch;
        DataTable dtKeep;
        DataTable dtTeam;
        string teamSelected;
        string yearMatch;
        int count;

        private void Form1_Load(object sender, EventArgs e)
        {
            //connect to mysql
            sqlConnection = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");

            //fill dt matchdate and set minimal date
            dTP_MatchDate.MinDate = new DateTime(2016, 2, 14);
            dtMatchDate = new DataTable();
            sqlQuery = "SELECT SUBSTRING(match_date, 1, locate('-', match_date)-1) from `match`;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtMatchDate);

            //set dtp to today
            dTP_MatchDate.Value = DateTime.Today.Date;
            yearMatch = dTP_MatchDate.Value.Year.ToString();
            count = 1;
            for (int i = 0; i < dtMatchDate.Rows.Count; i++)
            {
                if (dTP_MatchDate.Value.Year.ToString() == dtMatchDate.Rows[i][0].ToString())
                {
                    count++;
                }
            }
            SetMatchID(count, yearMatch);

            //fill dt team home
            dtTeamHome = new DataTable();
            sqlQuery = "SELECT team_name FROM team;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamHome);
            for (int i = 0; i < dtTeamHome.Rows.Count; i++)
            {
                cBox_TeamHome.Items.Add(dtTeamHome.Rows[i][0].ToString());
            }

            //fill dt team away
            dtTeamAway = new DataTable();
            sqlQuery = "SELECT team_name FROM team;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamAway);
            for (int i = 0; i < dtTeamAway.Rows.Count; i++)
            {
                cBox_TeamAway.Items.Add(dtTeamAway.Rows[i][0].ToString());
            }

            //create dt dmatch for dgv
            dtdmatch = new DataTable();
            dtdmatch.Columns.Add("Team");
            dtdmatch.Columns.Add("Player");
            dtdmatch.Columns.Add("Type");
            dGV_dmatch.DataSource = dtdmatch;

            //add cbox type
            cBox_Type.Items.Add("GO");
            cBox_Type.Items.Add("GP");
            cBox_Type.Items.Add("GW");
            cBox_Type.Items.Add("CR");
            cBox_Type.Items.Add("CY");
            cBox_Type.Items.Add("PM");

            //create dt for keeping data to be inserted to dmatch table
            dtKeep = new DataTable();
            dtKeep.Columns.Add("Minute");
            dtKeep.Columns.Add("TeamID");
            dtKeep.Columns.Add("PlayerID");
        }

        private void dTP_MatchDate_ValueChanged(object sender, EventArgs e)
        {
            yearMatch = dTP_MatchDate.Value.Year.ToString();
            count = 1;
            for (int i = 0; i < dtMatchDate.Rows.Count; i++)
            {
                if (dTP_MatchDate.Value.Year.ToString() == dtMatchDate.Rows[i][0].ToString())
                {
                    count++;
                }
            }
            SetMatchID(count, yearMatch);
        }

        void SetMatchID(int count, string yearMatch)
        {
            if (count < 10)
            {
                tB_MatchID.Text = $"{yearMatch}00{count}";
            }
            else if (count > 9 && count < 100)
            {
                tB_MatchID.Text = $"{yearMatch}0{count}";
            }
            else
            {
                tB_MatchID.Text = $"{yearMatch}{count}";
            }
        }

        private void cBox_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_TeamHome.SelectedItem != null && cBox_TeamAway.SelectedItem != null)
            {
                if (cBox_TeamHome.SelectedIndex == cBox_TeamAway.SelectedIndex)
                {
                    MessageBox.Show("Team Home can't be same with Team Away");
                    cBox_TeamHome.SelectedItem = null;
                }
                else
                {
                    AddTeam();
                }
            }
        }

        private void cBox_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_TeamHome.SelectedItem != null && cBox_TeamAway.SelectedItem != null)
            {
                if (cBox_TeamAway.SelectedIndex == cBox_TeamHome.SelectedIndex && cBox_TeamHome.SelectedItem != null && cBox_TeamAway.SelectedItem != null)
                {
                    MessageBox.Show("Team Away can't be same with Team Home");
                    cBox_TeamAway.SelectedItem = null;
                }
                else
                {
                    AddTeam();
                }
            }
        }

        void AddTeam()
        {
            cBox_Team.Items.Clear();
            cBox_Team.Items.Add(cBox_TeamHome.Text);
            cBox_Team.Items.Add(cBox_TeamAway.Text);
            dtTeam = new DataTable();
            sqlQuery = $"SELECT team_id, team_name FROM team WHERE team_name = '{cBox_TeamHome.Text}' OR team_name = '{cBox_TeamAway.Text}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeam);
        }

        private void cBox_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_Team.SelectedItem != null)
            {
                dtselectedTeam = new DataTable();
                sqlQuery = $"SELECT team_id FROM team WHERE team_name = '{cBox_Team.Text}';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtselectedTeam);
                teamSelected = dtselectedTeam.Rows[0][0].ToString();

                dtPlayer = new DataTable();
                sqlQuery = $"SELECT player_id, player_name FROM player WHERE player.team_id = '{teamSelected}';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtPlayer);
                cBox_Player.DataSource = dtPlayer;
                cBox_Player.ValueMember = "player_id";
                cBox_Player.DisplayMember = "player_name";
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (tB_Minute.Text == string.Empty || cBox_Team.SelectedItem == null || cBox_Type.SelectedItem == null)
            {
                MessageBox.Show("Please fill all fields");
            }
            else
            {
                dtdmatch.Rows.Add(cBox_Team.Text, cBox_Player.Text, cBox_Type.Text);
                dtKeep.Rows.Add(tB_Minute.Text, teamSelected, cBox_Player.SelectedValue);
                dTP_MatchDate.Enabled = false;
                cBox_TeamHome.Enabled = false;
                cBox_TeamAway.Enabled = false;
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow now = dGV_dmatch.CurrentRow;
            dGV_dmatch.Rows.Remove(now);
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            for (int i = 0; i < dGV_dmatch.Rows.Count - 1; i++)
            {
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
                sqlQuery = $"INSERT INTO dmatch VALUES ('{tB_MatchID.Text}', '{dtKeep.Rows[i][0]}', " +
                    $"'{dtKeep.Rows[i][1]}', '{dtKeep.Rows[i][2]}', '{dtdmatch.Rows[i][2]}', '0');";
                sqlCommand.CommandText = sqlQuery;
                sqlCommand.ExecuteNonQuery();
            }

            int goalHome = 0;
            int goalAway = 0;

            for (int i = 0; i < dGV_dmatch.Rows.Count - 1; i++)
            {
                if (dtdmatch.Rows[i][0] == dtTeam.Rows[0][1])
                {
                    if (dtdmatch.Rows[i][2].ToString() == "GO" || dtdmatch.Rows[i][2].ToString() == "GP")
                    {
                        goalHome++;
                    }
                    else if (dtdmatch.Rows[i][2].ToString() == "GW")
                    {
                        goalAway++;
                    }
                }
                else
                {
                    if (dtdmatch.Rows[i][2].ToString() == "GO" || dtdmatch.Rows[i][2].ToString() == "GP")
                    {
                        goalAway++;
                    }
                    else if (dtdmatch.Rows[i][2].ToString() == "GW")
                    {
                        goalHome++;
                    }
                }
            }

            string date = $"{dTP_MatchDate.Value.Year}-{dTP_MatchDate.Value.Month}-{dTP_MatchDate.Value.Day}";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlQuery = $"INSERT INTO `match` VALUES ('{tB_MatchID.Text}', '{date}', '{dtTeam.Rows[0][0]}', '{dtTeam.Rows[1][0]}', '{goalHome}', '{goalAway}', 'M002', '0');";
            sqlCommand.CommandText = sqlQuery;
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Successfully Inserted");
            Reset();
        }

        void Reset()
        {
            //matchdate dan matchid
            dtMatchDate = new DataTable();
            sqlQuery = "SELECT SUBSTRING(match_date, 1, locate('-', match_date)-1) from `match`;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtMatchDate);

            count = 1;
            for (int i = 0; i < dtMatchDate.Rows.Count; i++)
            {
                if (dTP_MatchDate.Value.Year.ToString() == dtMatchDate.Rows[i][0].ToString())
                {
                    count++;
                }
            }
            SetMatchID(count, yearMatch);
            dTP_MatchDate.Enabled = true;

            //combo box
            cBox_TeamHome.Enabled = true;
            cBox_TeamAway.Enabled = true;
            cBox_TeamHome.SelectedItem = null;
            cBox_TeamAway.SelectedItem = null;

            //dgv
            tB_Minute.Text = string.Empty;
            cBox_Player.DataSource = null;
            cBox_Team.SelectedItem = null;
            cBox_Team.Items.Clear();
            cBox_Type.SelectedItem = null;
            dtdmatch.Rows.Clear();
        }
    }
}
