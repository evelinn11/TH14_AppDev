﻿namespace TH14___Evelin_Alim_Natadjaja
{
    partial class InsertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_MatchID = new System.Windows.Forms.Label();
            this.lb_TeamHome = new System.Windows.Forms.Label();
            this.lb_MatchDate = new System.Windows.Forms.Label();
            this.lb_TeamAway = new System.Windows.Forms.Label();
            this.dTP_MatchDate = new System.Windows.Forms.DateTimePicker();
            this.lb_Minute = new System.Windows.Forms.Label();
            this.lb_Team = new System.Windows.Forms.Label();
            this.lb_Player = new System.Windows.Forms.Label();
            this.lb_Type = new System.Windows.Forms.Label();
            this.dGV_dmatch = new System.Windows.Forms.DataGridView();
            this.tB_MatchID = new System.Windows.Forms.TextBox();
            this.tB_Minute = new System.Windows.Forms.TextBox();
            this.cBox_TeamHome = new System.Windows.Forms.ComboBox();
            this.cBox_TeamAway = new System.Windows.Forms.ComboBox();
            this.cBox_Team = new System.Windows.Forms.ComboBox();
            this.cBox_Player = new System.Windows.Forms.ComboBox();
            this.cBox_Type = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_dmatch)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_MatchID
            // 
            this.lb_MatchID.AutoSize = true;
            this.lb_MatchID.Location = new System.Drawing.Point(37, 45);
            this.lb_MatchID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_MatchID.Name = "lb_MatchID";
            this.lb_MatchID.Size = new System.Drawing.Size(51, 13);
            this.lb_MatchID.TabIndex = 0;
            this.lb_MatchID.Text = "Match ID";
            // 
            // lb_TeamHome
            // 
            this.lb_TeamHome.AutoSize = true;
            this.lb_TeamHome.Location = new System.Drawing.Point(37, 87);
            this.lb_TeamHome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_TeamHome.Name = "lb_TeamHome";
            this.lb_TeamHome.Size = new System.Drawing.Size(65, 13);
            this.lb_TeamHome.TabIndex = 1;
            this.lb_TeamHome.Text = "Team Home";
            // 
            // lb_MatchDate
            // 
            this.lb_MatchDate.AutoSize = true;
            this.lb_MatchDate.Location = new System.Drawing.Point(406, 49);
            this.lb_MatchDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_MatchDate.Name = "lb_MatchDate";
            this.lb_MatchDate.Size = new System.Drawing.Size(63, 13);
            this.lb_MatchDate.TabIndex = 2;
            this.lb_MatchDate.Text = "Match Date";
            // 
            // lb_TeamAway
            // 
            this.lb_TeamAway.AutoSize = true;
            this.lb_TeamAway.Location = new System.Drawing.Point(406, 92);
            this.lb_TeamAway.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_TeamAway.Name = "lb_TeamAway";
            this.lb_TeamAway.Size = new System.Drawing.Size(63, 13);
            this.lb_TeamAway.TabIndex = 3;
            this.lb_TeamAway.Text = "Team Away";
            // 
            // dTP_MatchDate
            // 
            this.dTP_MatchDate.Location = new System.Drawing.Point(486, 46);
            this.dTP_MatchDate.Margin = new System.Windows.Forms.Padding(2);
            this.dTP_MatchDate.Name = "dTP_MatchDate";
            this.dTP_MatchDate.Size = new System.Drawing.Size(186, 20);
            this.dTP_MatchDate.TabIndex = 4;
            this.dTP_MatchDate.Value = new System.DateTime(2024, 6, 1, 0, 0, 0, 0);
            this.dTP_MatchDate.ValueChanged += new System.EventHandler(this.dTP_MatchDate_ValueChanged);
            // 
            // lb_Minute
            // 
            this.lb_Minute.AutoSize = true;
            this.lb_Minute.Location = new System.Drawing.Point(472, 174);
            this.lb_Minute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Minute.Name = "lb_Minute";
            this.lb_Minute.Size = new System.Drawing.Size(39, 13);
            this.lb_Minute.TabIndex = 5;
            this.lb_Minute.Text = "Minute";
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(472, 206);
            this.lb_Team.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(34, 13);
            this.lb_Team.TabIndex = 6;
            this.lb_Team.Text = "Team";
            // 
            // lb_Player
            // 
            this.lb_Player.AutoSize = true;
            this.lb_Player.Location = new System.Drawing.Point(472, 239);
            this.lb_Player.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Player.Name = "lb_Player";
            this.lb_Player.Size = new System.Drawing.Size(36, 13);
            this.lb_Player.TabIndex = 7;
            this.lb_Player.Text = "Player";
            // 
            // lb_Type
            // 
            this.lb_Type.AutoSize = true;
            this.lb_Type.Location = new System.Drawing.Point(472, 275);
            this.lb_Type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_Type.Name = "lb_Type";
            this.lb_Type.Size = new System.Drawing.Size(31, 13);
            this.lb_Type.TabIndex = 8;
            this.lb_Type.Text = "Type";
            // 
            // dGV_dmatch
            // 
            this.dGV_dmatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_dmatch.Location = new System.Drawing.Point(37, 139);
            this.dGV_dmatch.Margin = new System.Windows.Forms.Padding(2);
            this.dGV_dmatch.MultiSelect = false;
            this.dGV_dmatch.Name = "dGV_dmatch";
            this.dGV_dmatch.ReadOnly = true;
            this.dGV_dmatch.RowHeadersWidth = 82;
            this.dGV_dmatch.RowTemplate.Height = 33;
            this.dGV_dmatch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_dmatch.Size = new System.Drawing.Size(387, 217);
            this.dGV_dmatch.TabIndex = 9;
            // 
            // tB_MatchID
            // 
            this.tB_MatchID.Enabled = false;
            this.tB_MatchID.Location = new System.Drawing.Point(113, 43);
            this.tB_MatchID.Margin = new System.Windows.Forms.Padding(2);
            this.tB_MatchID.Name = "tB_MatchID";
            this.tB_MatchID.Size = new System.Drawing.Size(115, 20);
            this.tB_MatchID.TabIndex = 10;
            // 
            // tB_Minute
            // 
            this.tB_Minute.Location = new System.Drawing.Point(532, 171);
            this.tB_Minute.Margin = new System.Windows.Forms.Padding(2);
            this.tB_Minute.Name = "tB_Minute";
            this.tB_Minute.Size = new System.Drawing.Size(115, 20);
            this.tB_Minute.TabIndex = 11;
            // 
            // cBox_TeamHome
            // 
            this.cBox_TeamHome.FormattingEnabled = true;
            this.cBox_TeamHome.Location = new System.Drawing.Point(113, 86);
            this.cBox_TeamHome.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_TeamHome.Name = "cBox_TeamHome";
            this.cBox_TeamHome.Size = new System.Drawing.Size(114, 21);
            this.cBox_TeamHome.TabIndex = 12;
            this.cBox_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cBox_TeamHome_SelectedIndexChanged);
            // 
            // cBox_TeamAway
            // 
            this.cBox_TeamAway.FormattingEnabled = true;
            this.cBox_TeamAway.Location = new System.Drawing.Point(486, 92);
            this.cBox_TeamAway.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_TeamAway.Name = "cBox_TeamAway";
            this.cBox_TeamAway.Size = new System.Drawing.Size(114, 21);
            this.cBox_TeamAway.TabIndex = 13;
            this.cBox_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cBox_TeamAway_SelectedIndexChanged);
            // 
            // cBox_Team
            // 
            this.cBox_Team.FormattingEnabled = true;
            this.cBox_Team.Location = new System.Drawing.Point(532, 206);
            this.cBox_Team.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_Team.Name = "cBox_Team";
            this.cBox_Team.Size = new System.Drawing.Size(114, 21);
            this.cBox_Team.TabIndex = 14;
            this.cBox_Team.SelectedIndexChanged += new System.EventHandler(this.cBox_Team_SelectedIndexChanged);
            // 
            // cBox_Player
            // 
            this.cBox_Player.FormattingEnabled = true;
            this.cBox_Player.Location = new System.Drawing.Point(532, 239);
            this.cBox_Player.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_Player.Name = "cBox_Player";
            this.cBox_Player.Size = new System.Drawing.Size(114, 21);
            this.cBox_Player.TabIndex = 15;
            // 
            // cBox_Type
            // 
            this.cBox_Type.FormattingEnabled = true;
            this.cBox_Type.Location = new System.Drawing.Point(532, 275);
            this.cBox_Type.Margin = new System.Windows.Forms.Padding(2);
            this.cBox_Type.Name = "cBox_Type";
            this.cBox_Type.Size = new System.Drawing.Size(114, 21);
            this.cBox_Type.TabIndex = 16;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(486, 315);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(76, 23);
            this.btn_Add.TabIndex = 17;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(586, 315);
            this.btn_Delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(76, 23);
            this.btn_Delete.TabIndex = 18;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(279, 378);
            this.btn_Insert.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(156, 23);
            this.btn_Insert.TabIndex = 19;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // InsertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 412);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.cBox_Type);
            this.Controls.Add(this.cBox_Player);
            this.Controls.Add(this.cBox_Team);
            this.Controls.Add(this.cBox_TeamAway);
            this.Controls.Add(this.cBox_TeamHome);
            this.Controls.Add(this.tB_Minute);
            this.Controls.Add(this.tB_MatchID);
            this.Controls.Add(this.dGV_dmatch);
            this.Controls.Add(this.lb_Type);
            this.Controls.Add(this.lb_Player);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.lb_Minute);
            this.Controls.Add(this.dTP_MatchDate);
            this.Controls.Add(this.lb_TeamAway);
            this.Controls.Add(this.lb_MatchDate);
            this.Controls.Add(this.lb_TeamHome);
            this.Controls.Add(this.lb_MatchID);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "InsertForm";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_dmatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lb_MatchID;
        private System.Windows.Forms.Label lb_TeamHome;
        private System.Windows.Forms.Label lb_MatchDate;
        private System.Windows.Forms.Label lb_TeamAway;
        private System.Windows.Forms.DateTimePicker dTP_MatchDate;
        private System.Windows.Forms.Label lb_Minute;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.Label lb_Player;
        private System.Windows.Forms.Label lb_Type;
        private System.Windows.Forms.DataGridView dGV_dmatch;
        private System.Windows.Forms.TextBox tB_MatchID;
        private System.Windows.Forms.TextBox tB_Minute;
        private System.Windows.Forms.ComboBox cBox_TeamHome;
        private System.Windows.Forms.ComboBox cBox_TeamAway;
        private System.Windows.Forms.ComboBox cBox_Team;
        private System.Windows.Forms.ComboBox cBox_Player;
        private System.Windows.Forms.ComboBox cBox_Type;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Insert;
    }
}

